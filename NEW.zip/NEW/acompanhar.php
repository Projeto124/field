<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Acompanhar</title>
  </head>
  <body>
    <form action="processaBusca.php" method="POST">

      <label for="codigo">Insira o código de acompanhamento:</label>
      <input type="text" name="codigo" id="codigo">
      <br>

      <input type="submit" name="Enviar" value="Enviar">
    </form>

  </body>
</html>
