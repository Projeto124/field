<?php
	$host = "localhost";
	$user = "root";
	$password = "";
	$database = "field";

	$url = "http://localhost/NEW/";

	$conn=mysqli_connect($host, $user, $password, $database);
?>
