<html>
<head>
	<title>Busca de terrenos</title>
	<link rel="stylesheet" type="text/css" href="estilos.css">
</head>
	<body>
		<div class="container">
			<form action="processaBusca.php" method="POST">

        <label for="rua">Digite o nome da rua:</label>
        <input type="text" name="rua" id="rua">
<br>

				<input type="submit" name="Buscar">
			</form>
		</div>
	</body>
</html>
