<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width-device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="curso/node_modules/bootstrap/compiler/bootstrap.css">
    <style media="screen">

    </style>
    <title>Cadastro</title>
  </head>
  <body>
    <nav class="navbar navbar-expand-sm bg-dark justify-content-center mb-sm-5">

				<span class="navbar-text h1 ml-auto" >
					FIELD
				</span>

				<h4 id="nomeUsuario"></h4>
				 <a class="navbar ml-auto btn btn-dark"   href="saida.php">Sair</a>

		</nav>

      <h2>CADASTRO DO TERRENO</h2>

      <form class="form-control" action="processa.php" method="post" enctype="multipart/form-data"><br>

        <div class="form-control">
          <label for="endereco">Endereço</label>
          <input type="text" name="endereco" value=""><br>
        </div>
        <div class="form-group">
          <label for="numero">Número da propriedade (opcional)</label>
          <input type="number" name="numero" value=""><br>
        </div>

        <div class="form-group">
          <label for="gravidade">Gravidade</label>
          <ul>
            <input type="radio" name="gravidade" value="Baixo"> Baixo<br>
            <input type="radio" name="gravidade" value="Moderado"> Moderado<br>
            <input type="radio" name="gravidade" value="Crítico"> Crítico<br>
            </ul>
            <br>
        </div>
          <div class="form-group">
            <label for="imagem">Insira a imagem do terreno</label>
            <input type="file" name="imagem" value=""><br>
          </div>
          <br>
          <input type="float" id="lat" name="latitude" value="">
          <input type="float" id="lng" name="longitude" value="">

          <input class="btn btn-dark m-auto" type="submit" name="enviar" value="Enviar">
      </form>

<button onclick="getLocation()">Clique Aqui</button>

      <script>
var x=document.getElementById("d");
function getLocation()
  {
  if (navigator.geolocation)
    {
    navigator.geolocation.getCurrentPosition(showPosition,showError);
    }
  else{x.innerHTML="Seu browser não suporta Geolocalização.";}
  }
function showPosition(position)
  {
  document.getElementById('lat').value = position.coords.latitude;
  document.getElementById('lng').value =  position.coords.longitude;
  x.innerHTML="Latitude: " + position.coords.latitude +
  "<br>Longitude: " + position.coords.longitude;
  }
function showError(error)
  {
  switch(error.code)
    {
    case error.PERMISSION_DENIED:
      x.innerHTML="Usuário rejeitou a solicitação de Geolocalização."
      break;
    case error.POSITION_UNAVAILABLE:
      x.innerHTML="Localização indisponível."
      break;
    case error.TIMEOUT:
      x.innerHTML="A requisição expirou."
      break;
    case error.UNKNOWN_ERROR:
      x.innerHTML="Algum erro desconhecido aconteceu."
      break;
    }
  }
</script>



    </div>
  </body>
</html>
